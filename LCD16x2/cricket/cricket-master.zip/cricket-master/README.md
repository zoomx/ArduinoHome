# cricket
A game using arduino and lcd screen
